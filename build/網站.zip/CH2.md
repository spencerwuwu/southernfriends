<?php
$top = file_get_contents('basic.php');
echo $top;
?>
<div class="one item content" markdown="1">

###3/4
![](img/Ch2/第二章.png)
字



</div>
<?php
$end = file_get_contents('end.php');
echo $end;
?>
