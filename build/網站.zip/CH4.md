<?php
$top = file_get_contents('basic.php');
echo $top;
?>

<div class="one item content" markdown="1">

<div class="law-icon-con">
<div class="law-icon">
<img src="img/Ch4/ICON_大錘子.png" />
</div>
</div>

####《就業服務法》
####有關外國人工作重要條文

字



</div>
  <?php
  $end = file_get_contents('end.php');
  echo $end;
  ?>
